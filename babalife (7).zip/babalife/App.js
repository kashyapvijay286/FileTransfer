import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, StyleSheet, TouchableWithoutFeedback } from 'react-native';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons'; 

// Import BOTH providers
import { LifeProvider } from './context/LifeContext';
import { ListProvider } from './context/ListContext'; 

// Import Screens
import HomeScreen from './screens/HomeScreen';
import MonthScreen from './screens/MonthScreen';
import LifeScreen from './screens/LifeScreen';
import ProfileScreen from './screens/ProfileScreen';
import ListsScreen from './screens/ListsScreen'; 
import FinanceScreen from './screens/FinanceScreen'; 
import BirthdayScreen from './screens/BirthdayScreen';

const Tab = createBottomTabNavigator();

// Dummy Component to stop 'More' tab from loading a blank screen
const DummyComponent = () => null;

// =====================================================================
// MAIN NAVIGATOR (Zero-Crash Architecture)
// =====================================================================
function AppNavigator() {
  const [moreMenuVisible, setMoreMenuVisible] = useState(false);
  const navigation = useNavigation();

  const navigateTo = (screenName) => {
    setMoreMenuVisible(false); // Close Modal
    navigation.navigate(screenName); // Navigate smoothly
  };

  return (
    <>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false, 
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            // NEW ORDER ICONS
            if (route.name === 'Weekends') iconName = focused ? 'albums' : 'albums-outline';
            else if (route.name === 'Months') iconName = focused ? 'grid' : 'grid-outline';
            else if (route.name === 'Life') iconName = focused ? 'map' : 'map-outline';
            else if (route.name === 'Lists') iconName = focused ? 'list' : 'list-outline'; 
            else if (route.name === 'More') iconName = focused ? 'menu' : 'menu-outline';
            
            return <Ionicons name={iconName || 'ellipse'} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#007AFF', 
          tabBarInactiveTintColor: '#8E8E93', 
          tabBarStyle: {
            paddingBottom: 15, 
            paddingTop: 8,
            height: 68,        
            backgroundColor: '#ffffff',
            borderTopWidth: 1,
            borderTopColor: '#E5E5EA',
          },
          tabBarLabelStyle: { fontSize: 11, fontWeight: '600' }
        })}
      >
        {/* ======================================= */}
        {/* VISIBLE TABS (Order: Weekends -> Months -> Life -> Lists -> More) */}
        {/* ======================================= */}
        <Tab.Screen name="Weekends" component={HomeScreen} />
        <Tab.Screen name="Months" component={MonthScreen} />
        <Tab.Screen name="Life" component={LifeScreen} />
        <Tab.Screen name="Lists" component={ListsScreen} />
        
        {/* THE INTERCEPTOR TAB */}
        <Tab.Screen 
          name="More" 
          component={DummyComponent} 
          listeners={{
            tabPress: (e) => {
              e.preventDefault(); // Navigation block karega
              setMoreMenuVisible(true); // Modal pop karega
            },
          }}
        />

        {/* ======================================= */}
        {/* HIDDEN TABS (Menu se khulenge par bottom bar me nahi dikhenge) */}
        {/* ======================================= */}
        <Tab.Screen 
          name="Finance" 
          component={FinanceScreen} 
          options={{ tabBarButton: () => null }} 
        />
        <Tab.Screen 
          name="BirthdayScreen" 
          component={BirthdayScreen} 
          options={{ tabBarButton: () => null }} 
        />
        <Tab.Screen 
          name="ProfileScreen" 
          component={ProfileScreen} 
          options={{ tabBarButton: () => null }} 
        />

      </Tab.Navigator>

      {/* ======================================= */}
      {/* THE POP-OUT MENU MODAL */}
      {/* ======================================= */}
      <Modal visible={moreMenuVisible} transparent={true} animationType="fade">
        <TouchableWithoutFeedback onPress={() => setMoreMenuVisible(false)}>
          <View style={styles.modalOverlay}>
            
            <View style={styles.popoutMenu}>
              
              <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo('Finance')}>
                <Text style={styles.menuIcon}>💸</Text>
                <Text style={styles.menuText}>Finance & Wealth</Text>
              </TouchableOpacity>
              
              <View style={styles.menuDivider} />

              <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo('BirthdayScreen')}>
                <Text style={styles.menuIcon}>🎂</Text>
                <Text style={styles.menuText}>Birthdays</Text>
              </TouchableOpacity>
              
              <View style={styles.menuDivider} />

              <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo('ProfileScreen')}>
                <Text style={styles.menuIcon}>👤</Text>
                <Text style={styles.menuText}>My Profile</Text>
              </TouchableOpacity>
              
            </View>

          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </>
  );
}

export default function App() {
  return (
    <LifeProvider>
      <ListProvider>
        <NavigationContainer>
          <AppNavigator />
        </NavigationContainer>
      </ListProvider>
    </LifeProvider>
  );
}

// =====================================================================
// POP-OUT MENU STYLES
// =====================================================================
const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.15)',
    justifyContent: 'flex-end',
    alignItems: 'flex-end', 
    paddingBottom: 85, 
    paddingRight: 10,
  },
  popoutMenu: {
    backgroundColor: '#ffffff',
    width: 220,
    borderRadius: 16,
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 10,
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 12,
  },
  menuIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  menuText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#1C1C1E',
  },
  menuDivider: {
    height: 1,
    backgroundColor: '#F2F2F7',
    marginVertical: 2,
    marginHorizontal: 10,
  }
});