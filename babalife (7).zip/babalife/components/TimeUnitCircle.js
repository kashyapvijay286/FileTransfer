import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import Svg, { Path } from 'react-native-svg';

export default function TimeUnitCircle({ text, colors = [], isPast, isVerified, hasReminder, festival, onPress, size = 28 }) {
  const radius = size / 2;
  const outerSize = size + 6; 

  const needsVerification = isPast && colors.length > 0 && !isVerified;

  const polarToCartesian = (centerX, centerY, r, angleInDegrees) => {
    const angleInRadians = (angleInDegrees + 180) * Math.PI / 180.0; 
    return {
      x: centerX + (r * Math.cos(angleInRadians)),
      y: centerY + (r * Math.sin(angleInRadians))
    };
  };

  const emptyColor = isPast ? '#4A4A4A' : '#E5E5EA'; 
  let circleTextColor = isPast && colors.length === 0 ? '#fff' : '#555';
  if (colors.length > 0) circleTextColor = '#fff';
  
  // FESTIVAL COLOR OVERRIDE
  if (festival && festival.color) circleTextColor = festival.color;

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.6} style={[styles.wrapper, { width: outerSize, height: outerSize }]}>
      <View style={[styles.outerRing, { 
        width: outerSize, height: outerSize, borderRadius: outerSize / 2, 
        borderWidth: needsVerification ? 2 : 0 
      }]}>
        <View style={[styles.circleBg, { width: size, height: size, borderRadius: radius, backgroundColor: emptyColor }]}>
          {colors.length === 1 && <View style={[StyleSheet.absoluteFill, { backgroundColor: colors[0] }]} />}
          {colors.length > 1 && (
            <Svg width={size} height={size}>
              {(() => {
                const totalWeight = colors.length * (colors.length + 1) / 2;
                let currentAngle = 0;
                return colors.map((col, index) => {
                  const weight = colors.length - index;
                  const angle = (weight / totalWeight) * 360;
                  const endAngle = currentAngle + angle;
                  const start = polarToCartesian(radius, radius, radius, endAngle);
                  const end = polarToCartesian(radius, radius, radius, currentAngle);
                  const largeArcFlag = angle <= 180 ? "0" : "1";
                  const d = ["M", radius, radius, "L", start.x, start.y, "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y, "Z"].join(" ");
                  currentAngle = endAngle;
                  return <Path key={index} d={d} fill={col} />;
                });
              })()}
            </Svg>
          )}
        </View>
      </View>
      <View style={[StyleSheet.absoluteFill, styles.overlay]}>
        <Text style={[styles.dateText, { color: circleTextColor }]}>{text}</Text>
      </View>
      {hasReminder && <View style={styles.redDot} />}
      
      {/* TINY FESTIVAL TEXT - EXTREMELY CLOSE TO CIRCLE */}
      {festival && festival.name ? (
        <Text style={[styles.festivalText, festival.color ? { color: festival.color } : { color: '#8E8E93' }]} numberOfLines={1}>{festival.name}</Text>
      ) : null}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: { justifyContent: 'center', alignItems: 'center' },
  outerRing: { justifyContent: 'center', alignItems: 'center', borderColor: '#000', backgroundColor: 'transparent' },
  circleBg: { overflow: 'hidden' },
  overlay: { justifyContent: 'center', alignItems: 'center' },
  dateText: { fontSize: 11, fontWeight: '800', letterSpacing: -0.5 },
  redDot: { position: 'absolute', bottom: 0, right: 0, width: 8, height: 8, borderRadius: 4, backgroundColor: '#FF3B30', borderWidth: 1.5, borderColor: '#fff' },
  festivalText: { position: 'absolute', bottom: -7.5, fontSize: 7, fontWeight: '800', textAlign: 'center', width: 48, overflow: 'hidden' }
});