import React, { useContext, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Modal, Alert } from 'react-native';
import { ListContext } from '../context/ListContext';

export default function SpreadsheetView({ listId, onBack }) {
  const { customLists, setCustomLists } = useContext(ListContext);
  const activeList = customLists.find(l => l.id === listId);

  // Modals State
  const [colMenuVisible, setColMenuVisible] = useState(false);
  const [selectedCol, setSelectedCol] = useState(null);
  
  const [rowMenuVisible, setRowMenuVisible] = useState(false);
  const [selectedRowIndex, setSelectedRowIndex] = useState(null);

  const [addColVisible, setAddColVisible] = useState(false);
  const [newColName, setNewColName] = useState('');

  if (!activeList) return null;
  const { wrapText, textSize, hideRowNumber } = activeList.settings;

  // --- CORE UPDATER ---
  const updateListProperty = (key, val) => {
    setCustomLists(customLists.map(l => l.id === listId ? { ...l, [key]: val } : l));
  };

  // --- CELL DATA UPDATER ---
  const updateCell = (rowId, colId, value) => {
    const updatedRows = activeList.rows.map(row => {
      if (row.id === rowId) return { ...row, cells: { ...row.cells, [colId]: value } };
      return row;
    });
    updateListProperty('rows', updatedRows);
  };

  // --- COLUMN HEADER ACTIONS ---
  const openColMenu = (col) => {
    setSelectedCol(col);
    setColMenuVisible(true);
  };

  const updateColAttr = (key, val) => {
    updateListProperty('columns', activeList.columns.map(c => c.id === selectedCol.id ? { ...c, [key]: val } : c));
    setSelectedCol({ ...selectedCol, [key]: val }); // Update local state for modal
  };

  const moveCol = (dir) => {
    const index = activeList.columns.findIndex(c => c.id === selectedCol.id);
    if ((dir === -1 && index === 0) || (dir === 1 && index === activeList.columns.length - 1)) return;
    const newCols = [...activeList.columns];
    [newCols[index], newCols[index + dir]] = [newCols[index + dir], newCols[index]];
    updateListProperty('columns', newCols);
  };

  const deleteCol = () => {
    updateListProperty('columns', activeList.columns.filter(c => c.id !== selectedCol.id));
    setColMenuVisible(false);
  };

  const addColumn = (type) => {
    if (!newColName.trim()) return;
    const newCol = { id: 'c_' + Date.now(), name: newColName, type: type, width: 120 };
    updateListProperty('columns', [...activeList.columns, newCol]);
    setAddColVisible(false);
    setNewColName('');
  };

  // --- ROW ACTIONS (S.No & Ordering) ---
  const addRow = () => {
    const maxSerial = activeList.rows.reduce((max, r) => Math.max(max, r.serial || 0), 0);
    const newRow = { id: 'r_' + Date.now(), serial: maxSerial + 1, cells: {} };
    updateListProperty('rows', [...activeList.rows, newRow]);
  };

  const openRowMenu = (index) => {
    setSelectedRowIndex(index);
    setRowMenuVisible(true);
  };

  const moveRow = (dir) => {
    const index = selectedRowIndex;
    if ((dir === -1 && index === 0) || (dir === 1 && index === activeList.rows.length - 1)) return;
    
    const newRows = [...activeList.rows];
    [newRows[index], newRows[index + dir]] = [newRows[index + dir], newRows[index]];
    
    // Swap S.No so it remains sequential logically, or keep it attached to the row data.
    // In Notion, moving a row doesn't change its intrinsic ID, just its display order.
    const tempSerial = newRows[index].serial;
    newRows[index].serial = newRows[index + dir].serial;
    newRows[index + dir].serial = tempSerial;

    updateListProperty('rows', newRows);
    setSelectedRowIndex(index + dir); // Follow the row
  };

  const deleteRow = () => {
    const rowId = activeList.rows[selectedRowIndex].id;
    updateListProperty('rows', activeList.rows.filter(r => r.id !== rowId));
    setRowMenuVisible(false);
  };

  // --- RENDER TABLE ---
  return (
    <View style={styles.container}>
      
      {/* Table Toolbar */}
      <View style={styles.toolbar}>
        <TouchableOpacity style={styles.backBtn} onPress={onBack}>
          <Text style={styles.backBtnTxt}>{'< Back'}</Text>
        </TouchableOpacity>
        <Text style={styles.tableName} numberOfLines={1}>{activeList.title}</Text>
        <TouchableOpacity style={styles.addColBtn} onPress={() => setAddColVisible(true)}>
          <Text style={styles.addColTxt}>+ Column</Text>
        </TouchableOpacity>
      </View>

      {/* Spreadsheet Horizontal Scroll */}
      <ScrollView horizontal={true} style={styles.tableScrollX} bounces={false}>
        <ScrollView contentContainerStyle={styles.tableScrollY} bounces={false}>
          <View style={styles.tableWrapper}>
            
            {/* --- HEADERS --- */}
            <View style={styles.tableHeaderRow}>
              {!hideRowNumber && (
                <View style={[styles.tableCell, styles.headerCell, { width: 50 }]}>
                  <Text style={styles.headerTxt}>S.No</Text>
                </View>
              )}
              
              {activeList.columns.map(col => (
                <TouchableOpacity key={col.id} style={[styles.tableCell, styles.headerCell, { width: col.width }]} onPress={() => openColMenu(col)}>
                  <Text style={styles.headerTxt} numberOfLines={1}>{col.name} ⚙️</Text>
                </TouchableOpacity>
              ))}
              
              {/* Row Action Header */}
              <View style={[styles.tableCell, styles.headerCell, { width: 40 }]} />
            </View>

            {/* --- ROWS --- */}
            {activeList.rows.map((row, index) => (
              <View key={row.id} style={[styles.tableRow, index % 2 === 1 && styles.tableRowAlt]}>
                
                {!hideRowNumber && (
                  <View style={[styles.tableCell, { width: 50, backgroundColor: '#F9F9F9' }]}>
                    <Text style={[styles.serialTxt, {fontSize: textSize}]}>{row.serial}</Text>
                  </View>
                )}
                
                {activeList.columns.map(col => {
                  const cellVal = row.cells[col.id];
                  let cellContent;
                  
                  if (col.type === 'Checkbox') {
                    cellContent = (
                      <TouchableOpacity style={[styles.checkbox, cellVal && styles.checkboxChecked]} onPress={() => updateCell(row.id, col.id, !cellVal)}>
                        {cellVal && <Text style={styles.checkMark}>✓</Text>}
                      </TouchableOpacity>
                    );
                  } else {
                    cellContent = (
                      <TextInput 
                        style={[styles.cellInput, {fontSize: textSize}]} 
                        value={cellVal ? String(cellVal) : ''} 
                        onChangeText={(val) => updateCell(row.id, col.id, val)} 
                        placeholder="..." 
                        keyboardType={col.type === 'Number' ? 'numeric' : 'default'} 
                        multiline={wrapText} 
                      />
                    );
                  }

                  return <View key={col.id} style={[styles.tableCell, { width: col.width }]}>{cellContent}</View>;
                })}
                
                {/* Row Options (⋮) */}
                <TouchableOpacity style={[styles.tableCell, styles.rowActionCell, { width: 40 }]} onPress={() => openRowMenu(index)}>
                  <Text style={styles.rowActionTxt}>⋮</Text>
                </TouchableOpacity>

              </View>
            ))}

            {/* Add Row Footer */}
            <TouchableOpacity style={styles.newRowBtn} onPress={addRow}>
              <Text style={styles.newRowTxt}>+ Add New Row</Text>
            </TouchableOpacity>

          </View>
        </ScrollView>
      </ScrollView>

      {/* ======================================================== */}
      {/* MODAL 1: INLINE COLUMN HEADER SETTINGS                   */}
      {/* ======================================================== */}
      <Modal visible={colMenuVisible} transparent={true} animationType="fade">
        <TouchableOpacity style={styles.modalBg} activeOpacity={1} onPress={() => setColMenuVisible(false)}>
          <View style={styles.inlineMenuCard}>
            <Text style={styles.menuTitle}>Edit Column</Text>
            <TextInput 
              style={styles.menuInput} 
              value={selectedCol?.name} 
              onChangeText={(val) => updateColAttr('name', val)} 
            />
            
            <View style={styles.menuDivider} />
            
            <Text style={styles.menuSubTitle}>Column Width: {selectedCol?.width}px</Text>
            <View style={styles.btnGroupRow}>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => updateColAttr('width', Math.max(60, selectedCol.width - 20))}><Text style={styles.ctrlBtnTxt}>➖ Shrink</Text></TouchableOpacity>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => updateColAttr('width', selectedCol.width + 20)}><Text style={styles.ctrlBtnTxt}>➕ Expand</Text></TouchableOpacity>
            </View>

            <Text style={styles.menuSubTitle}>Move Column</Text>
            <View style={styles.btnGroupRow}>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => moveCol(-1)}><Text style={styles.ctrlBtnTxt}>◀ Left</Text></TouchableOpacity>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => moveCol(1)}><Text style={styles.ctrlBtnTxt}>Right ▶</Text></TouchableOpacity>
            </View>

            <View style={styles.menuDivider} />
            
            <TouchableOpacity style={styles.dangerBtn} onPress={deleteCol}>
              <Text style={styles.dangerBtnTxt}>🗑️ Delete Column</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* ======================================================== */}
      {/* MODAL 2: INLINE ROW SETTINGS (REORDER & DELETE)          */}
      {/* ======================================================== */}
      <Modal visible={rowMenuVisible} transparent={true} animationType="fade">
        <TouchableOpacity style={styles.modalBg} activeOpacity={1} onPress={() => setRowMenuVisible(false)}>
          <View style={styles.inlineMenuCard}>
            <Text style={styles.menuTitle}>Row Action (S.No: {activeList.rows[selectedRowIndex]?.serial})</Text>
            <View style={styles.menuDivider} />
            
            <View style={styles.btnGroupRow}>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => moveRow(-1)}><Text style={styles.ctrlBtnTxt}>▲ Move Up</Text></TouchableOpacity>
              <TouchableOpacity style={styles.ctrlBtn} onPress={() => moveRow(1)}><Text style={styles.ctrlBtnTxt}>▼ Move Down</Text></TouchableOpacity>
            </View>

            <View style={styles.menuDivider} />
            <TouchableOpacity style={styles.dangerBtn} onPress={deleteRow}>
              <Text style={styles.dangerBtnTxt}>🗑️ Delete Row</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* ======================================================== */}
      {/* MODAL 3: ADD NEW COLUMN                                  */}
      {/* ======================================================== */}
      <Modal visible={addColVisible} transparent={true} animationType="fade">
        <TouchableOpacity style={styles.modalBg} activeOpacity={1} onPress={() => setAddColVisible(false)}>
          <View style={styles.inlineMenuCard}>
            <Text style={styles.menuTitle}>Add New Column</Text>
            <TextInput style={styles.menuInput} placeholder="Column Name..." value={newColName} onChangeText={setNewColName} />
            <View style={styles.menuDivider} />
            
            <ScrollView style={{maxHeight: 200}}>
              {['Text', 'Number', 'Amount', 'Checkbox', 'Date', 'Link'].map(type => (
                <TouchableOpacity key={type} style={{paddingVertical: 12}} onPress={() => addColumn(type)}>
                  <Text style={{fontSize: 16, color: '#007AFF', fontWeight: '500'}}>+ {type}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  toolbar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#E5E5EA', paddingVertical: 10, paddingHorizontal: 15 },
  backBtn: { paddingRight: 15 },
  backBtnTxt: { color: '#007AFF', fontSize: 16, fontWeight: '700' },
  tableName: { flex: 1, fontSize: 16, fontWeight: '800', color: '#1C1C1E', textAlign: 'center' },
  addColBtn: { paddingLeft: 15 },
  addColTxt: { color: '#007AFF', fontSize: 14, fontWeight: '700' },
  
  tableScrollX: { flex: 1, backgroundColor: '#F9F9F9' },
  tableScrollY: { minWidth: 500, padding: 10, paddingBottom: 50 },
  tableWrapper: { backgroundColor: '#fff', borderRadius: 8, overflow: 'hidden', borderWidth: 1, borderColor: '#E5E5EA' },
  
  tableHeaderRow: { flexDirection: 'row', backgroundColor: '#F2F2F7', borderBottomWidth: 2, borderBottomColor: '#E5E5EA' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#F2F2F7', backgroundColor: '#fff' },
  tableRowAlt: { backgroundColor: '#FAFAFB' },
  
  tableCell: { justifyContent: 'center', paddingVertical: 8, paddingHorizontal: 10, borderRightWidth: 1, borderRightColor: '#E5E5EA' },
  headerCell: { paddingVertical: 12, backgroundColor: '#F2F2F7' },
  headerTxt: { fontSize: 13, fontWeight: '800', color: '#555' },
  
  serialTxt: { fontSize: 13, fontWeight: '800', color: '#A1A1A6', textAlign: 'center' },
  cellInput: { padding: 0, margin: 0, color: '#1C1C1E', minHeight: 20 },
  
  checkbox: { width: 22, height: 22, borderRadius: 6, borderWidth: 1.5, borderColor: '#C7C7CC', justifyContent: 'center', alignItems: 'center' },
  checkboxChecked: { backgroundColor: '#34C759', borderColor: '#34C759' },
  checkMark: { color: '#fff', fontSize: 14, fontWeight: '900' },
  
  rowActionCell: { alignItems: 'center', backgroundColor: '#F9F9F9' },
  rowActionTxt: { fontSize: 18, color: '#8E8E93', fontWeight: 'bold' },
  
  newRowBtn: { padding: 12, backgroundColor: '#fff', alignItems: 'center' },
  newRowTxt: { color: '#007AFF', fontSize: 14, fontWeight: '700' },

  // INLINE MODAL STYLES (Clean & Centered like Airtable/Notion menus)
  modalBg: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', alignItems: 'center' },
  inlineMenuCard: { backgroundColor: '#fff', width: 300, borderRadius: 16, padding: 20, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10, elevation: 5 },
  menuTitle: { fontSize: 16, fontWeight: '800', color: '#1C1C1E', marginBottom: 10, textAlign: 'center' },
  menuSubTitle: { fontSize: 12, fontWeight: '700', color: '#8E8E93', marginBottom: 8, marginTop: 10 },
  menuInput: { backgroundColor: '#F2F2F7', borderRadius: 8, height: 40, paddingHorizontal: 12, fontSize: 15, fontWeight: '600' },
  menuDivider: { height: 1, backgroundColor: '#E5E5EA', marginVertical: 15 },
  btnGroupRow: { flexDirection: 'row', gap: 10 },
  ctrlBtn: { flex: 1, backgroundColor: '#E5F1FF', paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  ctrlBtnTxt: { color: '#007AFF', fontWeight: '700', fontSize: 13 },
  dangerBtn: { backgroundColor: '#FDECEF', paddingVertical: 12, borderRadius: 8, alignItems: 'center' },
  dangerBtnTxt: { color: '#FF3B30', fontWeight: '800', fontSize: 14 }
});