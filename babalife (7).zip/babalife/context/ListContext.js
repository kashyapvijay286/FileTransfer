import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const ListContext = createContext();

export const ListProvider = ({ children }) => {
  // === NOTION-STYLE DATABASE SCHEMA ===
  const [customLists, setCustomLists] = useState([
    {
      id: 'L1',
      title: 'Weekend Grocery 🛒',
      tags: ['Shopping', 'Home'],
      settings: { wrapText: false, textSize: 14, hideRowNumber: false },
      columns: [
        { id: 'c_name', name: 'Item Name', type: 'Text', width: 180 },
        { id: 'c_qty', name: 'Quantity', type: 'Number', width: 100 },
        { id: 'c_done', name: 'Bought', type: 'Checkbox', width: 90 }
      ],
      rows: [
        { id: 'r1', cells: { 'c_name': 'Milk', 'c_qty': '2', 'c_done': false } },
        { id: 'r2', cells: { 'c_name': 'Bread', 'c_qty': '1', 'c_done': true } }
      ]
    }
  ]);

  // Load lists from local storage on app start
  useEffect(() => {
    const loadLists = async () => {
      try {
        const savedLists = await AsyncStorage.getItem('@custom_lists_data');
        if (savedLists) {
          setCustomLists(JSON.parse(savedLists));
        }
      } catch (e) { console.log("Failed to load lists"); }
    };
    loadLists();
  }, []);

  // Save lists to local storage whenever they change
  useEffect(() => {
    const saveLists = async () => {
      try {
        await AsyncStorage.setItem('@custom_lists_data', JSON.stringify(customLists));
      } catch (e) { console.log("Failed to save lists"); }
    };
    saveLists();
  }, [customLists]);

  return (
    <ListContext.Provider value={{ customLists, setCustomLists }}>
      {children}
    </ListContext.Provider>
  );
};