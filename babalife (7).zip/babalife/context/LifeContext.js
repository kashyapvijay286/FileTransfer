import React, { createContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const LifeContext = createContext();

export const LifeProvider = ({ children }) => {
  const colorPalette = [
    '#FF3B30', '#007AFF', '#34C759', '#FFCC00', '#AF52DE', 
    '#FF9500', '#5AC8FA', '#5856D6', '#FF2D55', '#A2845E'
  ];

  const [profile, setProfile] = useState({ name: 'Baba', dob: '1995-01-01', lifespan: 70, dp: null });
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [goals, setGoals] = useState([]);
  const [taggedDays, setTaggedDays] = useState({});
  const [weekendNotes, setWeekendNotes] = useState({});
  const [extendedWeekends, setExtendedWeekends] = useState({});
  const [yearlyNotes, setYearlyNotes] = useState({});
  const [monthlyNotes, setMonthlyNotes] = useState({});
  const [googleAuth, setGoogleAuth] = useState({ email: null, lastSync: null });
  const [username, setUsername] = useState('');

  const getAppState = () => ({ profile, taggedDays, goals, weekendNotes, extendedWeekends, yearlyNotes, monthlyNotes });

  const loadCloudData = async (email) => {
    try {
      const data = await AsyncStorage.getItem(`@cloud_${email}`);
      if (data) {
        const parsed = JSON.parse(data);
        if(parsed.profile) setProfile(parsed.profile);
        if(parsed.taggedDays) setTaggedDays(parsed.taggedDays);
        if(parsed.goals) setGoals(parsed.goals);
        if(parsed.weekendNotes) setWeekendNotes(parsed.weekendNotes);
        if(parsed.extendedWeekends) setExtendedWeekends(parsed.extendedWeekends);
        if(parsed.yearlyNotes) setYearlyNotes(parsed.yearlyNotes);
        if(parsed.monthlyNotes) setMonthlyNotes(parsed.monthlyNotes);
        return true;
      }
    } catch(e) {}
    return false;
  };

  const syncToCloud = async (email) => {
    try {
      const data = getAppState();
      await AsyncStorage.setItem(`@cloud_${email}`, JSON.stringify(data));
      const now = new Date().toISOString();
      setGoogleAuth({ email, lastSync: now });
    } catch(e) {}
  };

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      let h = now.getHours(); let m = now.getMinutes();
      const ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12; m = m < 10 ? '0'+m : m;
      const currentTimeStr = `${h}:${m} ${ampm}`;

      setTaggedDays(prev => {
        let updated = false;
        let newState = { ...prev };
        Object.keys(newState).forEach(dateId => {
          const reminder = newState[dateId]?.reminder;
          if (reminder && reminder.time === currentTimeStr && !reminder.notified) {
            Alert.alert(`⏰ ALARM RINGING!`, `Date: ${dateId.split('-').reverse().join('-')}\nMessage: ${reminder.msg}`);
            newState[dateId] = { ...newState[dateId], reminder: { ...reminder, notified: true } };
            updated = true;
          }
        });
        return updated ? newState : prev;
      });

      if (googleAuth.email && googleAuth.lastSync) {
        const lastSyncTime = new Date(googleAuth.lastSync).getTime();
        const diffDays = (now.getTime() - lastSyncTime) / (1000 * 3600 * 24);
        if (diffDays >= 7) syncToCloud(googleAuth.email);
      }
    }, 10000);
    return () => clearInterval(interval);
  }, [googleAuth, profile, taggedDays, goals, weekendNotes, extendedWeekends, yearlyNotes, monthlyNotes]);

  const getGoalColorsForDate = (dateId) => {
    const dayData = taggedDays[dateId];
    if (!dayData || !dayData.goals || dayData.goals.length === 0) return []; 
    const activeGoals = goals.filter(g => dayData.goals.includes(g.id));
    if (activeGoals.length === 0) return [];
    activeGoals.sort((a, b) => goals.indexOf(a) - goals.indexOf(b));
    return activeGoals.map(g => g.color);
  };

  const getReminder = (dateId) => taggedDays[dateId]?.reminder || null;
  const getFestival = (dateId) => taggedDays[dateId]?.festival || null;

  return (
    <LifeContext.Provider value={{ 
      profile, setProfile, selectedYear, setSelectedYear,
      goals, setGoals, colorPalette, 
      taggedDays, setTaggedDays, 
      weekendNotes, setWeekendNotes, extendedWeekends, setExtendedWeekends,
      yearlyNotes, setYearlyNotes, monthlyNotes, setMonthlyNotes,
      getGoalColorsForDate, getReminder, getFestival,
      googleAuth, setGoogleAuth, loadCloudData, syncToCloud,
      username, setUsername
    }}>
      {children}
    </LifeContext.Provider>
  );
};